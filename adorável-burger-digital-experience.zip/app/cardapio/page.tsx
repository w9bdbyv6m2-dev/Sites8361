'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, Star, Sparkles, ArrowLeft, X, Check, Flame, Filter } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProductModal from '@/components/ProductModal';
import Tilt3DCard from '@/components/Tilt3DCard';
import { MENU_ITEMS, MENU_CATEGORIES, MenuItem } from '@/lib/menuData';
import { useCart } from '@/components/CartProvider';
import { useToast } from '@/components/ToastProvider';

export default function CardapioPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'recommended' | 'price-asc' | 'price-desc'>('recommended');
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const [addedItemIds, setAddedItemIds] = useState<{ [key: string]: boolean }>({});
  
  const { addItem } = useCart();
  const { showToast } = useToast();

  // Reset scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Compute categories with counts
  const categoryCounts = useMemo(() => {
    const counts: { [key: string]: number } = { Todos: MENU_ITEMS.length };
    MENU_ITEMS.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, []);

  const allTags = useMemo(() => {
    const set = new Set<string>();
    MENU_ITEMS.forEach(item => item.tags?.forEach(t => set.add(t)));
    return Array.from(set);
  }, []);

  const filteredItems = useMemo(() => {
    let result = MENU_ITEMS.filter((item) => {
      const matchCategory = selectedCategory === 'Todos' || item.category === selectedCategory;
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.ingredients && item.ingredients.some(ing => ing.toLowerCase().includes(searchQuery.toLowerCase())));
      const matchTag = !selectedTag || item.tags?.includes(selectedTag);

      return matchCategory && matchSearch && matchTag;
    });

    if (sortBy === 'price-asc') {
      result = [...result].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result = [...result].sort((a, b) => b.price - a.price);
    }

    return result;
  }, [selectedCategory, searchQuery, selectedTag, sortBy]);

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleQuickAdd = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      quantity: 1,
    });

    // Animate checkmark feedback
    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItemIds((prev) => ({ ...prev, [item.id]: false }));
    }, 1200);

    showToast({
      title: item.name,
      description: 'Adicionado ao seu pedido!',
      image: item.image,
      type: 'cart',
    });
  };

  return (
    <main className="bg-dark min-h-screen text-white flex flex-col pt-20">
      <Navbar />

      {/* Hero Header Section */}
      <section className="relative py-14 md:py-18 bg-dark-surface border-b border-white/10 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] max-w-[650px] max-h-[650px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />
        
        <div className="container mx-auto px-6 max-w-7xl relative z-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <Link
                href="/"
                onClick={() => window.scrollTo({ top: 0, behavior: 'instant' })}
                className="inline-flex items-center gap-2 text-white/60 hover:text-amber-400 text-sm mb-4 transition-colors group font-semibold"
              >
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                <span>Voltar ao Início</span>
              </Link>
              <h1 className="text-4xl sm:text-6xl font-display font-bold tracking-tight text-white">
                Nosso <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-white/40">Cardápio Exclusivo</span>
              </h1>
              <p className="text-white/70 text-base sm:text-lg max-w-xl mt-3 font-light leading-relaxed">
                Explore nossas criações artesanais. Selecionadas com pães brioche selados, blend Angus certificado e molhos autorais em Vicente Pires.
              </p>
            </div>

            {/* Quick Stats Pill */}
            <div className="flex items-center gap-5 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md shrink-0">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                <div>
                  <span className="block text-xl font-bold text-white leading-none">{MENU_ITEMS.length}</span>
                  <span className="text-[11px] text-white/60">Opções no Menu</span>
                </div>
              </div>
              <div className="w-px h-8 bg-white/10" />
              <div>
                <span className="block text-xl font-bold text-amber-400 leading-none">4.9 ★</span>
                <span className="text-[11px] text-white/60">Avaliação iFood</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Non-Sticky Filter Toolbar (Scrolls naturally with page) */}
      <section className="bg-dark/90 border-b border-white/10 py-6 mb-4">
        <div className="container mx-auto px-6 max-w-7xl space-y-6">
          
          {/* Search bar & Sort Controls */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Input Bar */}
            <div className="relative w-full md:max-w-lg">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-400/70" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Pesquisar por hambúrguer, cheddar, molho trufado..."
                className="w-full bg-white/5 border border-white/15 rounded-full pl-12 pr-10 py-3.5 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400/80 transition-colors shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1"
                  title="Limpar busca"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Tag filters & Sort dropdown */}
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-between md:justify-end">
              {/* Quick Tag Badges */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
                <span className="text-xs text-white/40 uppercase font-bold shrink-0 hidden sm:inline flex items-center gap-1">
                  <Filter className="w-3 h-3" /> Tags:
                </span>
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                    className={`text-xs px-3.5 py-1.5 rounded-full font-semibold transition-all shrink-0 ${
                      selectedTag === tag
                        ? 'bg-amber-400 text-dark font-extrabold shadow-md'
                        : 'bg-white/5 border border-white/10 text-white/70 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Sort selector */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/40 font-bold shrink-0 hidden sm:inline">Ordem:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white/5 border border-white/15 rounded-full px-4 py-2 text-xs font-bold text-white focus:outline-none cursor-pointer hover:border-white/30 transition-colors"
                >
                  <option value="recommended" className="bg-dark text-white">Recomendados</option>
                  <option value="price-asc" className="bg-dark text-white">Menor Preço</option>
                  <option value="price-desc" className="bg-dark text-white">Maior Preço</option>
                </select>
              </div>
            </div>
          </div>

          {/* Interactive Category Tabs with Counters */}
          <div className="flex items-center gap-2.5 overflow-x-auto pb-2 scrollbar-none border-t border-white/5 pt-4">
            {MENU_CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat;
              const count = categoryCounts[cat] || 0;

              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`relative px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all shrink-0 flex items-center gap-2 ${
                    isActive
                      ? 'text-dark shadow-[0_0_20px_rgba(255,255,255,0.25)]'
                      : 'text-white/70 hover:text-white hover:bg-white/5 border border-white/10'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeCategoryBg"
                      className="absolute inset-0 bg-white rounded-full z-0"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{cat}</span>
                  <span
                    className={`relative z-10 text-[10px] px-2 py-0.5 rounded-full font-extrabold ${
                      isActive ? 'bg-dark/10 text-dark' : 'bg-white/10 text-white/60'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

        </div>
      </section>

      {/* Main Cardapio Product Grid */}
      <section className="py-8 flex-1 container mx-auto px-6 max-w-7xl">
        
        {/* Results Header Summary */}
        <div className="flex items-center justify-between mb-8 pb-3 border-b border-white/5">
          <p className="text-white/60 text-sm font-medium">
            Exibindo <span className="text-amber-400 font-bold">{filteredItems.length}</span> {filteredItems.length === 1 ? 'item' : 'itens'}
            {selectedCategory !== 'Todos' && <span> em <strong className="text-white">{selectedCategory}</strong></span>}
            {selectedTag && <span> com a tag <strong className="text-amber-300">#{selectedTag}</strong></span>}
          </p>

          {(selectedCategory !== 'Todos' || searchQuery || selectedTag) && (
            <button
              onClick={() => {
                setSelectedCategory('Todos');
                setSearchQuery('');
                setSelectedTag(null);
              }}
              className="text-xs text-white/50 hover:text-amber-400 underline font-semibold transition-colors"
            >
              Resetar todos os filtros
            </button>
          )}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="py-24 text-center space-y-4 max-w-md mx-auto"
          >
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-amber-400 mb-2">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white">Nenhum hambúrguer encontrado</h3>
            <p className="text-white/50 text-sm leading-relaxed">
              Não encontramos nenhum item correspondente a &quot;{searchQuery || selectedTag}&quot;. Tente buscar por outros termos ou resetar seus filtros.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('Todos');
                setSearchQuery('');
                setSelectedTag(null);
              }}
              className="px-6 py-3 bg-white text-dark hover:bg-amber-300 rounded-full text-xs font-extrabold uppercase tracking-wider transition-all shadow-lg active:scale-95"
            >
              Ver Todo o Cardápio
            </button>
          </motion.div>
        ) : (
          <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => {
                const isRecentlyAdded = addedItemIds[item.id];

                return (
                  <motion.div
                    layout
                    initial={{ opacity: 0, scale: 0.94, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.94, y: 20 }}
                    transition={{ duration: 0.35 }}
                    key={item.id}
                  >
                    <Tilt3DCard maxTilt={8} scaleOnHover={1.03} className="h-full">
                      <div
                        onClick={() => setSelectedProduct(item)}
                        className="group relative flex flex-col bg-dark-surface border border-white/10 rounded-3xl overflow-hidden hover:border-amber-400/40 transition-all duration-300 shadow-xl cursor-pointer hover:shadow-[0_20px_50px_rgba(0,0,0,0.85)] h-full"
                      >
                        {/* Subtle Top Glow on Hover */}
                        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-amber-400/0 group-hover:via-amber-400/80 to-transparent transition-all duration-500" />

                        {/* Product Image Frame */}
                        <div className="relative h-64 sm:h-72 bg-black overflow-hidden">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            className="object-cover transition-transform duration-700 group-hover:scale-108 transform-gpu"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-dark-surface via-transparent to-transparent opacity-85" />

                          {/* Top Badges */}
                          <div className="absolute top-4 left-4 right-4 flex justify-between items-start z-10 pointer-events-none">
                            {item.badge ? (
                              <span className="bg-amber-400 text-dark text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-lg flex items-center gap-1">
                                <Sparkles className="w-3 h-3 fill-dark" />
                                {item.badge}
                              </span>
                            ) : <span />}

                            {item.rating && (
                              <span className="bg-black/70 backdrop-blur-md border border-white/20 text-white text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                                {item.rating}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Card Body */}
                        <div className="p-6 flex flex-col flex-grow relative z-10 space-y-4">
                          <div>
                            <div className="flex justify-between items-start gap-3 mb-2">
                              <h3 className="text-xl font-bold text-white group-hover:text-amber-300 transition-colors leading-tight">
                                {item.name}
                              </h3>
                              <span className="text-lg font-black text-amber-400 shrink-0">
                                {formatPrice(item.price)}
                              </span>
                            </div>
                            <p className="text-white/60 text-xs sm:text-sm leading-relaxed line-clamp-2">
                              {item.description}
                            </p>
                          </div>

                          {/* Ingredients list chips */}
                          {item.ingredients && (
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {item.ingredients.slice(0, 3).map((ing, i) => (
                                <span key={i} className="text-[10px] bg-white/5 border border-white/10 text-white/70 px-2 py-0.5 rounded-lg">
                                  {ing}
                                </span>
                              ))}
                              {item.ingredients.length > 3 && (
                                <span className="text-[10px] text-white/40 self-center font-semibold">
                                  +{item.ingredients.length - 3} mais
                                </span>
                              )}
                            </div>
                          )}

                          {/* Bottom Quick Add Bar */}
                          <div className="pt-3 mt-auto flex items-center justify-between border-t border-white/5">
                            <span className="text-xs text-white/40 group-hover:text-white/80 transition-colors font-medium">
                              Clique para personalizar
                            </span>

                            <button
                              onClick={(e) => handleQuickAdd(e, item)}
                              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg active:scale-90 ${
                                isRecentlyAdded
                                  ? 'bg-emerald-500 text-white'
                                  : 'bg-white text-dark hover:bg-amber-300'
                              }`}
                              title="Adicionar direto"
                            >
                              {isRecentlyAdded ? (
                                <Check className="w-5 h-5" />
                              ) : (
                                <Plus className="w-5 h-5" />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </Tilt3DCard>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </section>

      {/* Detail Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />

      <Footer />
    </main>
  );
}
