import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import './globals.css';
import { CartProvider } from '@/components/CartProvider';
import { ToastProvider } from '@/components/ToastProvider';
import CartSidebar from '@/components/CartSidebar';
import FloatingWidgets from '@/components/FloatingWidgets';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' });
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-display' });

export const metadata: Metadata = {
  title: 'Adorável Burger | Hambúrgueres Artesanais em Brasília',
  description: 'O melhor hambúrguer artesanal de Vicente Pires, Brasília. Ingredientes selecionados, sabor inesquecível e entrega rápida.',
  openGraph: {
    title: 'Adorável Burger | Vicente Pires',
    description: 'O melhor hambúrguer artesanal de Vicente Pires, Brasília.',
    url: 'https://adoravelburger.com.br',
    siteName: 'Adorável Burger',
    locale: 'pt_BR',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${playfair.variable} scroll-smooth`}>
      <body className="bg-dark text-light antialiased font-sans overflow-x-hidden w-full relative" suppressHydrationWarning>
        <ToastProvider>
          <CartProvider>
            {children}
            <CartSidebar />
            <FloatingWidgets />
          </CartProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
