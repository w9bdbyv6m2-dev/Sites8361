import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import RunningMarquee from '@/components/RunningMarquee';
import SpecialCombos from '@/components/SpecialCombos';
import CraftAnatomy from '@/components/CraftAnatomy';
import BestSellers from '@/components/BestSellers';
import About from '@/components/About';
import Differentials from '@/components/Differentials';
import Gallery from '@/components/Gallery';
import Reviews from '@/components/Reviews';
import Location from '@/components/Location';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="bg-dark min-h-screen">
      <Navbar />
      <Hero />
      <RunningMarquee />
      <SpecialCombos />
      <CraftAnatomy />
      <BestSellers />
      <About />
      <Differentials />
      <Gallery />
      <Reviews />
      <Location />
      <FAQ />
      <Footer />
    </main>
  );
}
