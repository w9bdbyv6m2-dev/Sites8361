'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Tilt3DCard from './Tilt3DCard';

export default function About() {
  return (
    <section id="sobre" className="py-28 bg-dark-surface border-y border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-4">
              Nossa História em Vicente Pires
            </span>
            <h3 className="text-4xl sm:text-5xl font-display font-bold text-white mb-8 leading-[1.2]">
              Não é só um hambúrguer. É uma experiência Adorável.
            </h3>
            
            <div className="space-y-6 text-white/70 text-base sm:text-lg font-light leading-relaxed">
              <p>
                Nascemos em Vicente Pires com um propósito claro: elevar o padrão do hambúrguer artesanal no Distrito Federal. Acreditamos que cada ingrediente tem seu papel fundamental na construção de sabores inesquecíveis.
              </p>
              <p>
                Nosso blend bovino é moído diariamente, garantindo frescor e suculência incomparáveis. Nossos pães são fornecidos por padarias artesanais locais, e nossos molhos, produzidos do zero em nossa cozinha.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mt-10 pt-10 border-t border-white/10">
              <div>
                <span className="block text-3xl font-display font-bold text-amber-400 mb-1">100%</span>
                <span className="text-white/60 text-sm">Carne Angus Fresca</span>
              </div>
              <div>
                <span className="block text-3xl font-display font-bold text-amber-400 mb-1">Artesanal</span>
                <span className="text-white/60 text-sm">Molhos Autorais sem Conservantes</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <Tilt3DCard maxTilt={8} scaleOnHover={1.02}>
              <div className="relative h-[480px] md:h-[580px] rounded-3xl overflow-hidden border border-white/10 shadow-2xl group">
                <Image 
                  src="https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1000&q=80"
                  alt="Nossa Cozinha"
                  fill
                  className="object-cover transform-gpu group-hover:scale-105 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-dark/20" />
              </div>
            </Tilt3DCard>
            
            {/* Floating badge */}
            <motion.div 
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="absolute -bottom-8 -left-8 bg-dark border border-white/15 p-6 rounded-3xl shadow-2xl hidden md:block"
            >
              <div className="w-16 h-16 relative mb-3 overflow-hidden rounded-full border border-white/20">
                <Image 
                  src="https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=200&q=80"
                  alt="Quality Badge"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <p className="text-white font-bold text-base">Qualidade Premium</p>
              <p className="text-white/50 text-xs">Vicente Pires • DF</p>
            </motion.div>
          </motion.div>
          
        </div>
      </div>
    </section>
  );
}
