'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Star } from 'lucide-react';
import Tilt3DCard from './Tilt3DCard';

export default function BestSellers() {
  return (
    <section id="mais-pedidos" className="py-28 bg-dark relative overflow-hidden">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-3"
          >
            Os Favoritos de Vicente Pires
          </motion.span>

          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-6xl font-display font-bold text-white mb-6"
          >
            Assinatura Adorável
          </motion.h3>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-white/70 text-lg font-light leading-relaxed"
          >
            As combinações artesanais que conquistaram o DF. Veja o que torna cada um inesquecível.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          
          {/* Left Hero Showcase 3D Frame */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="hidden lg:block"
          >
            <Tilt3DCard maxTilt={10} scaleOnHover={1.02} className="w-full">
              <div className="relative h-[550px] rounded-3xl overflow-hidden shadow-2xl border border-white/10 group">
                <Image
                  src="https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=1000&q=80"
                  alt="Adorável Signature"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-1000 transform-gpu"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/90 via-dark/30 to-transparent" />
                <div className="absolute bottom-8 left-8 right-8">
                  <div className="bg-black/75 backdrop-blur-md border border-white/20 p-6 rounded-2xl flex justify-between items-center shadow-xl">
                    <div>
                      <p className="text-white text-xl font-bold mb-1">Bacon Supreme</p>
                      <p className="text-amber-300 text-sm font-semibold">O N° 1 em Vendas no iFood</p>
                    </div>
                    <Link
                      href="/cardapio"
                      className="bg-white text-dark px-5 py-2.5 rounded-full text-xs font-bold hover:bg-amber-300 transition-colors flex items-center gap-1 active:scale-95 shadow-lg"
                    >
                      Pedir no Cardápio <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </div>
            </Tilt3DCard>
          </motion.div>

          {/* Right Cards List */}
          <div className="flex flex-col gap-6">
            {[
              {
                number: "01",
                name: "Bacon Supreme",
                desc: "Equilíbrio perfeito entre o defumado do bacon crocante artesanal e o dulçor da nossa cebola caramelizada.",
                image: "https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=400&q=80",
                rating: "4.9"
              },
              {
                number: "02",
                name: "Adorável Clássico",
                desc: "A essência da casa. Blend 180g suculento com queijo prato derretido e pão brioche selado na manteiga.",
                image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=400&q=80",
                rating: "5.0"
              },
              {
                number: "03",
                name: "Truffle Smash Burger",
                desc: "Sofisticação em cada mordida. O aroma inconfundível do azeite de trufas brancas com maionese autoral.",
                image: "https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=400&q=80",
                rating: "4.9"
              }
            ].map((item, idx) => (
              <motion.div 
                key={item.name}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.15 }}
              >
                <Tilt3DCard maxTilt={6} scaleOnHover={1.02}>
                  <div className="group flex items-center gap-6 p-5 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-white/30 hover:bg-white/[0.06] transition-all duration-300 shadow-xl">
                    <div className="relative w-20 h-20 sm:w-28 sm:h-28 shrink-0 rounded-2xl overflow-hidden border border-white/10 group-hover:border-amber-400/50 transition-colors">
                      <Image 
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-500 transform-gpu"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-full text-[10px] font-bold text-amber-400 flex items-center gap-0.5">
                        <Star className="w-2.5 h-2.5 fill-amber-400" /> {item.rating}
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1.5">
                        <span className="text-amber-400 font-display font-bold italic text-lg">{item.number}.</span>
                        <h4 className="text-xl font-bold text-white group-hover:text-amber-200 transition-colors">{item.name}</h4>
                      </div>
                      <p className="text-white/60 leading-relaxed text-xs sm:text-sm mb-3">{item.desc}</p>
                      <Link
                        href="/cardapio"
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-300 hover:text-white transition-colors"
                      >
                        <span>Ver no Cardápio</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
