'use client';

import { useState } from 'react';
import { useCart } from './CartProvider';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Plus, ShoppingBag, Trash2, ArrowRight, FileText } from 'lucide-react';
import Image from 'next/image';
import MagneticButton from './MagneticButton';
import CheckoutModal from './CheckoutModal';

export default function CartSidebar() {
  const { items, isCartOpen, setIsCartOpen, updateQuantity, removeItem, cartTotal } = useCart();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const totalItems = items.reduce((acc, curr) => acc + curr.quantity, 0);

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <>
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-md z-[60]"
            />

            {/* Slide Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 220 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-dark border-l border-white/15 z-[70] shadow-[0_0_50px_rgba(0,0,0,0.9)] flex flex-col"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex items-center justify-between bg-dark-surface/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white">
                    <ShoppingBag className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl font-display font-bold text-white">Seu Pedido</h2>
                    <p className="text-xs text-white/50">{totalItems} {totalItems === 1 ? 'item selecionado' : 'itens selecionados'}</p>
                  </div>
                </div>

                <button
                  onClick={() => setIsCartOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items Scroll Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {items.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-white/40 space-y-3">
                    <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <ShoppingBag className="w-10 h-10 text-white/20" />
                    </div>
                    <p className="text-base font-medium text-white/60">Seu carrinho está vazio</p>
                    <p className="text-xs text-white/40 max-w-xs">
                      Explore nosso cardápio e escolha os melhores hambúrgueres artesanais de Brasília!
                    </p>
                  </div>
                ) : (
                  <AnimatePresence mode="popLayout">
                    {items.map((item) => (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, scale: 0.9, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.8, x: -30 }}
                        className="bg-white/5 border border-white/10 p-4 rounded-2xl flex gap-4 items-center relative group hover:border-white/20 transition-all"
                      >
                        <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 border border-white/10 bg-black">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            className="object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start gap-2">
                            <h4 className="text-white font-bold text-sm truncate">{item.name}</h4>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="text-white/30 hover:text-red-400 transition-colors p-1"
                              title="Remover do carrinho"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <p className="text-amber-400 font-bold text-sm my-1">{formatPrice(item.price)}</p>

                          {item.notes && (
                            <p className="text-[11px] text-white/60 italic flex items-center gap-1 mb-2 bg-white/5 px-2 py-0.5 rounded border border-white/5 truncate">
                              <FileText className="w-3 h-3 text-amber-400 shrink-0" />
                              <span className="truncate">{item.notes}</span>
                            </p>
                          )}

                          {/* Quantity selector */}
                          <div className="flex items-center gap-3 mt-2">
                            <div className="flex items-center bg-white/10 border border-white/10 rounded-full px-2 py-0.5">
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                className="text-white/70 hover:text-white p-1"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="text-white text-xs font-bold w-6 text-center">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="text-white/70 hover:text-white p-1"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <span className="text-xs font-bold text-white/80 ml-auto">
                              {formatPrice(item.price * item.quantity)}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </div>

              {/* Bottom Summary Bar */}
              {items.length > 0 && (
                <div className="p-6 border-t border-white/10 bg-dark-surface space-y-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-white/60">
                      <span>Subtotal</span>
                      <span>{formatPrice(cartTotal)}</span>
                    </div>
                    <div className="flex justify-between text-white/60">
                      <span>Entrega (Vicente Pires)</span>
                      <span className="text-emerald-400 font-medium">A calcular no checkout</span>
                    </div>
                    <div className="flex justify-between items-center text-lg font-bold text-white pt-2 border-t border-white/10">
                      <span>Total</span>
                      <span className="text-amber-400 text-2xl">{formatPrice(cartTotal)}</span>
                    </div>
                  </div>

                  <MagneticButton
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsCheckoutOpen(true);
                    }}
                    className="w-full py-4 bg-white text-dark rounded-full font-bold text-base flex items-center justify-center gap-2 hover:bg-amber-300 transition-all shadow-[0_0_30px_rgba(255,255,255,0.2)] active:scale-98"
                  >
                    <span>Avançar para Checkout</span>
                    <ArrowRight className="w-5 h-5" />
                  </MagneticButton>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <CheckoutModal isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} />
    </>
  );
}
