'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MapPin, CreditCard, Banknote, QrCode, ShoppingBag, Truck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useCart } from './CartProvider';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const { items, cartTotal, clearCart } = useCart();
  const [step, setStep] = useState<1 | 2>(1);
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    endereco: '',
    numero: '',
    complemento: '',
    bairro: '',
    metodoEntrega: 'delivery', // 'delivery' | 'buscar'
    metodoPagamento: 'pix', // 'pix' | 'cartao' | 'dinheiro'
    troco: ''
  });

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleMetodoEntrega = (metodo: 'delivery' | 'buscar') => {
    setFormData({ ...formData, metodoEntrega: metodo });
  };

  const handleMetodoPagamento = (metodo: 'pix' | 'cartao' | 'dinheiro') => {
    setFormData({ ...formData, metodoPagamento: metodo });
  };

  const submitOrder = () => {
    if (items.length === 0) return;

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (e) {
      // fallback if canvas-confetti fails
    }

    let message = `*NOVO PEDIDO - ADORÁVEL BURGER*%0A%0A`;
    
    message += `*CLIENTE*%0A`;
    message += `Nome: ${formData.nome}%0A`;
    message += `Telefone: ${formData.telefone}%0A%0A`;

    message += `*ENTREGA:* ${formData.metodoEntrega === 'delivery' ? 'Delivery (Vicente Pires)' : 'Vou Buscar na Loja'}%0A`;
    if (formData.metodoEntrega === 'delivery') {
      message += `Endereço: ${formData.endereco}, ${formData.numero}%0A`;
      if (formData.complemento) message += `Complemento: ${formData.complemento}%0A`;
      message += `Bairro: ${formData.bairro}%0A%0A`;
    }

    message += `*ITENS DO PEDIDO*%0A`;
    items.forEach(item => {
      message += `• ${item.quantity}x ${item.name} - ${formatPrice(item.price * item.quantity)}%0A`;
      if (item.notes) {
        message += `   _Obs: ${item.notes}_%0A`;
      }
    });
    message += `%0A*TOTAL DO PEDIDO: ${formatPrice(cartTotal)}*%0A%0A`;

    message += `*PAGAMENTO:* ${formData.metodoPagamento === 'pix' ? 'PIX' : formData.metodoPagamento === 'cartao' ? 'Cartão na Entrega' : 'Dinheiro na Entrega'}%0A`;
    if (formData.metodoPagamento === 'dinheiro' && formData.troco) {
      message += `Troco para: ${formData.troco}%0A`;
    }
    
    if (formData.metodoPagamento === 'pix') {
      message += `%0A_(Enviarei o comprovante PIX a seguir)_`;
    }

    const whatsappNumber = '5561981812664';
    const url = `https://wa.me/${whatsappNumber}?text=${message}`;
    
    window.open(url, '_blank');
    clearCart();
    onClose();
    setTimeout(() => setStep(1), 500); // Reset after closing
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-[80]"
          />
          <div className="fixed inset-0 flex items-center justify-center p-4 z-[90] pointer-events-none">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-dark-surface border border-white/10 w-full max-w-2xl max-h-[90vh] rounded-3xl shadow-2xl flex flex-col pointer-events-auto overflow-hidden relative"
            >
              <div className="p-6 border-b border-white/10 flex items-center justify-between sticky top-0 bg-dark-surface/90 backdrop-blur-sm z-10">
                <h2 className="text-2xl font-display font-bold text-white flex items-center gap-3">
                  Finalizar Pedido
                </h2>
                <button
                  onClick={onClose}
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 scrollbar-hide">
                {step === 1 ? (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="space-y-8"
                  >
                    {/* Informações Pessoais */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-brand text-dark flex items-center justify-center text-sm">1</span>
                        Seus Dados
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs text-white/60 ml-1">Nome Completo</label>
                          <input 
                            name="nome"
                            value={formData.nome}
                            onChange={handleInputChange}
                            type="text" 
                            placeholder="Ex: João Silva" 
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs text-white/60 ml-1">Telefone (WhatsApp)</label>
                          <input 
                            name="telefone"
                            value={formData.telefone}
                            onChange={handleInputChange}
                            type="tel" 
                            placeholder="(61) 99999-9999" 
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Entrega ou Retirada */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-brand text-dark flex items-center justify-center text-sm">2</span>
                        Como deseja receber?
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <button 
                          onClick={() => handleMetodoEntrega('delivery')}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${formData.metodoEntrega === 'delivery' ? 'border-brand bg-brand/10' : 'border-white/10 bg-white/5 hover:border-white/20'}`}
                        >
                          <Truck className={`w-8 h-8 mb-2 ${formData.metodoEntrega === 'delivery' ? 'text-brand' : 'text-white/50'}`} />
                          <span className={`font-medium ${formData.metodoEntrega === 'delivery' ? 'text-brand' : 'text-white'}`}>Delivery</span>
                        </button>
                        <button 
                          onClick={() => handleMetodoEntrega('buscar')}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${formData.metodoEntrega === 'buscar' ? 'border-brand bg-brand/10' : 'border-white/10 bg-white/5 hover:border-white/20'}`}
                        >
                          <MapPin className={`w-8 h-8 mb-2 ${formData.metodoEntrega === 'buscar' ? 'text-brand' : 'text-white/50'}`} />
                          <span className={`font-medium ${formData.metodoEntrega === 'buscar' ? 'text-brand' : 'text-white'}`}>Vou Buscar</span>
                        </button>
                      </div>

                      {/* Endereço Fields se for Delivery */}
                      <AnimatePresence>
                        {formData.metodoEntrega === 'delivery' && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-hidden pt-4"
                          >
                            <div className="md:col-span-2 space-y-1">
                              <label className="text-xs text-white/60 ml-1">Endereço (Rua, Quadra, Lote)</label>
                              <input 
                                name="endereco"
                                value={formData.endereco}
                                onChange={handleInputChange}
                                type="text" 
                                placeholder="Rua 08, Chácara 206..." 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs text-white/60 ml-1">Número</label>
                              <input 
                                name="numero"
                                value={formData.numero}
                                onChange={handleInputChange}
                                type="text" 
                                placeholder="Ex: 01" 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs text-white/60 ml-1">Bairro</label>
                              <input 
                                name="bairro"
                                value={formData.bairro}
                                onChange={handleInputChange}
                                type="text" 
                                placeholder="Vicente Pires" 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                              />
                            </div>
                            <div className="md:col-span-2 space-y-1">
                              <label className="text-xs text-white/60 ml-1">Complemento (Opcional)</label>
                              <input 
                                name="complemento"
                                value={formData.complemento}
                                onChange={handleInputChange}
                                type="text" 
                                placeholder="Apto, Bloco, etc." 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors"
                              />
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    <button 
                      onClick={() => setStep(2)}
                      disabled={!formData.nome || !formData.telefone || (formData.metodoEntrega === 'delivery' && (!formData.endereco || !formData.numero || !formData.bairro))}
                      className="w-full py-4 bg-brand text-dark rounded-xl font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-light transition-colors mt-8"
                    >
                      Continuar para Pagamento
                    </button>
                  </motion.div>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-brand text-dark flex items-center justify-center text-sm">3</span>
                          Forma de Pagamento
                        </h3>
                        <button onClick={() => setStep(1)} className="text-sm text-white/50 hover:text-white underline">Voltar</button>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button 
                          onClick={() => handleMetodoPagamento('pix')}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${formData.metodoPagamento === 'pix' ? 'border-brand bg-brand/10' : 'border-white/10 bg-white/5 hover:border-white/20'}`}
                        >
                          <QrCode className={`w-8 h-8 mb-2 ${formData.metodoPagamento === 'pix' ? 'text-brand' : 'text-white/50'}`} />
                          <span className={`font-medium ${formData.metodoPagamento === 'pix' ? 'text-brand' : 'text-white'}`}>PIX</span>
                        </button>
                        <button 
                          onClick={() => handleMetodoPagamento('cartao')}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${formData.metodoPagamento === 'cartao' ? 'border-brand bg-brand/10' : 'border-white/10 bg-white/5 hover:border-white/20'}`}
                        >
                          <CreditCard className={`w-8 h-8 mb-2 ${formData.metodoPagamento === 'cartao' ? 'text-brand' : 'text-white/50'}`} />
                          <span className={`font-medium ${formData.metodoPagamento === 'cartao' ? 'text-brand' : 'text-white'}`}>Cartão na Entrega</span>
                        </button>
                        <button 
                          onClick={() => handleMetodoPagamento('dinheiro')}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${formData.metodoPagamento === 'dinheiro' ? 'border-brand bg-brand/10' : 'border-white/10 bg-white/5 hover:border-white/20'}`}
                        >
                          <Banknote className={`w-8 h-8 mb-2 ${formData.metodoPagamento === 'dinheiro' ? 'text-brand' : 'text-white/50'}`} />
                          <span className={`font-medium ${formData.metodoPagamento === 'dinheiro' ? 'text-brand' : 'text-white'}`}>Dinheiro</span>
                        </button>
                      </div>

                      <AnimatePresence>
                        {formData.metodoPagamento === 'dinheiro' && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="pt-4 overflow-hidden"
                          >
                            <label className="text-xs text-white/60 ml-1">Precisa de troco para quanto?</label>
                            <input 
                              name="troco"
                              value={formData.troco}
                              onChange={handleInputChange}
                              type="text" 
                              placeholder="Ex: 50,00 ou Não preciso" 
                              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-brand transition-colors mt-1"
                            />
                          </motion.div>
                        )}
                        {formData.metodoPagamento === 'pix' && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="pt-4 overflow-hidden"
                          >
                            <div className="bg-white/5 border border-brand/30 rounded-xl p-4 flex gap-4 items-start">
                              <div className="p-2 bg-brand/20 rounded-lg shrink-0">
                                <QrCode className="w-6 h-6 text-brand" />
                              </div>
                              <div>
                                <h4 className="text-white font-bold mb-1">Chave PIX</h4>
                                <p className="text-white/70 text-sm mb-2">Envie o comprovante no WhatsApp logo após finalizar o pedido.</p>
                                <div className="bg-black/50 px-3 py-2 rounded-lg inline-block text-brand font-mono text-sm border border-white/10 select-all">
                                  61981812664
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    <div className="bg-dark/50 p-4 rounded-xl border border-white/5 mt-8">
                      <div className="flex justify-between items-center">
                        <span className="text-white/60">Total a Pagar</span>
                        <span className="text-2xl font-bold text-white">{formatPrice(cartTotal)}</span>
                      </div>
                    </div>

                    <button 
                      onClick={submitOrder}
                      className="w-full py-4 bg-brand text-dark rounded-xl font-bold text-lg hover:bg-brand-light transition-colors shadow-[0_0_30px_rgba(255,255,255,0.15)] flex justify-center items-center gap-2"
                    >
                      <ShoppingBag className="w-5 h-5" />
                      Enviar Pedido pelo WhatsApp
                    </button>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
