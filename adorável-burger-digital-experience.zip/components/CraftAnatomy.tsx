'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Beef, Flame, Award, ShieldCheck } from 'lucide-react';
import Image from 'next/image';
import Tilt3DCard from './Tilt3DCard';

const LAYERS = [
  {
    id: 'pao',
    title: 'Pão Brioche Artesanal',
    subtitle: 'Macio, Dourado & Selado na Manteiga',
    description: 'Pão fofinho assado diariamente por padarias parceiras de Brasília. Selado na chapa com manteiga de garrafa para garantir crocância sem absorver umidade.',
    image: 'https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=800&q=80',
    icon: Award,
  },
  {
    id: 'blend',
    title: 'Blend Angus 100% Certificado',
    subtitle: 'Moído Diariamente na Casa',
    description: 'Cortes selecionados de Angus bovino sem adição de gordura artificial. Moldado na hora para manter a suculência, fibras macias e sabor intenso.',
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80',
    icon: Beef,
  },
  {
    id: 'queijo',
    title: 'Queijos Especiais Derretidos',
    subtitle: 'Gouda, Cheddar Inglês & Brie',
    description: 'Derretidos no vapor diretamente sobre a carne ainda na chapa, criando um abraço aveludado e cremoso em cada mordida.',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    icon: Flame,
  },
  {
    id: 'molho',
    title: 'Molhos Autorais Adorável',
    subtitle: 'Receitas Exclusivas da Cozinha',
    description: 'Maionese verde de ervas frescas, molho chipotle defumado no ponto e maionese trufada. Feitos artesanalmente sem conservantes.',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=800&q=80',
    icon: ShieldCheck,
  }
];

export default function CraftAnatomy() {
  const [activeLayer, setActiveLayer] = useState(LAYERS[1]);

  return (
    <section className="py-28 bg-dark-surface relative overflow-hidden border-b border-white/5">
      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-flex items-center gap-2 mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" /> Segredo da Nossa Cozinha
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-6xl font-display font-bold text-white tracking-tight"
          >
            A Anatomia do <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-white/40">Burger Perfeito</span>
          </motion.h2>
          <p className="text-white/70 text-base sm:text-lg mt-4 font-light">
            Clique nas camadas para descobrir o rigor técnico e o amor que colocamos em cada detalhe.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Layer Selector Buttons */}
          <div className="lg:col-span-5 space-y-3">
            {LAYERS.map((layer) => {
              const isActive = activeLayer.id === layer.id;
              const IconComp = layer.icon;

              return (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayer(layer)}
                  className={`w-full text-left p-5 rounded-2xl border transition-all duration-300 flex items-center gap-4 ${
                    isActive
                      ? 'bg-white text-dark border-white shadow-[0_10px_30px_rgba(255,255,255,0.15)] font-bold scale-[1.02]'
                      : 'bg-white/5 text-white/70 border-white/10 hover:border-white/30 hover:bg-white/10'
                  }`}
                >
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                      isActive ? 'bg-dark text-amber-400' : 'bg-white/10 text-white'
                    }`}
                  >
                    <IconComp className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base sm:text-lg font-bold leading-snug">{layer.title}</h4>
                    <p className={`text-xs ${isActive ? 'text-dark/70' : 'text-white/50'}`}>
                      {layer.subtitle}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Animated Detail Display Card */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeLayer.id}
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <Tilt3DCard maxTilt={8} scaleOnHover={1.02} className="w-full">
                  <div className="bg-dark border border-white/15 rounded-3xl p-8 sm:p-10 relative overflow-hidden shadow-2xl">
                    <div className="relative h-64 sm:h-72 w-full rounded-2xl overflow-hidden mb-6 border border-white/10">
                      <Image
                        src={activeLayer.image}
                        alt={activeLayer.title}
                        fill
                        className="object-cover transform-gpu"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-dark via-transparent to-transparent opacity-80" />
                    </div>

                    <div className="space-y-3">
                      <span className="text-xs font-extrabold uppercase text-amber-400 tracking-wider">
                        {activeLayer.subtitle}
                      </span>
                      <h3 className="text-3xl font-display font-bold text-white">{activeLayer.title}</h3>
                      <p className="text-white/70 text-sm sm:text-base leading-relaxed font-light">
                        {activeLayer.description}
                      </p>
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
