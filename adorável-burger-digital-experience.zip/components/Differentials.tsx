'use client';

import { motion } from 'framer-motion';
import { Flame, Beef, Leaf, Clock } from 'lucide-react';
import Tilt3DCard from './Tilt3DCard';

const DIFFERENTIALS = [
  {
    icon: Flame,
    title: "Grelhado no Fogo Forte",
    description: "Sabor defumado autêntico com a crosta de Maillard perfeita que sela todos os sucos da carne."
  },
  {
    icon: Beef,
    title: "Blend Angus Selecionado",
    description: "100% carne bovina de cortes nobres Angus, moída diariamente na própria casa sem adição de conservantes."
  },
  {
    icon: Leaf,
    title: "Ingredientes Locais Especiais",
    description: "Pães brioche fornecidos diariamente por padarias de Brasília e hortaliças orgânicas sempre frescas."
  },
  {
    icon: Clock,
    title: "Agilidade & Pontualidade",
    description: "Sistema de embalagem térmica autoral que garante seu burger quente e crocante até a sua mesa."
  }
];

export default function Differentials() {
  return (
    <section className="py-28 bg-dark relative overflow-hidden">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-3"
          >
            Nossa Promessa
          </motion.span>
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-5xl font-display font-bold text-white mb-6"
          >
            Por Que Somos Adoráveis?
          </motion.h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {DIFFERENTIALS.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.12 }}
              >
                <Tilt3DCard maxTilt={8} scaleOnHover={1.03} className="h-full">
                  <div className="bg-dark-surface border border-white/10 hover:border-amber-400/40 p-8 rounded-3xl transition-colors duration-300 group flex flex-col h-full shadow-xl">
                    <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 text-amber-400 flex items-center justify-center mb-6 group-hover:bg-amber-400 group-hover:text-dark transition-all duration-300 shrink-0">
                      <Icon className="w-7 h-7" />
                    </div>
                    <h4 className="text-xl font-bold text-white mb-3 group-hover:text-amber-200 transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-white/60 leading-relaxed text-sm font-light">
                      {item.description}
                    </p>
                  </div>
                </Tilt3DCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
