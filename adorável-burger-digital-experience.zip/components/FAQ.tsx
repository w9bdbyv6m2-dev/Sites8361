'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const FAQS = [
  {
    question: "Vocês fazem entrega para quais regiões?",
    answer: "Atendemos principalmente Vicente Pires, Taguatinga, Águas Claras e Guará. Consulte a disponibilidade exata pelo nosso WhatsApp informando seu CEP."
  },
  {
    question: "Posso retirar no local?",
    answer: "Sim! Você pode fazer o pedido pelo WhatsApp e selecionar a opção de retirada. Informaremos assim que seu pedido estiver pronto."
  },
  {
    question: "Os hambúrgueres são artesanais?",
    answer: "100% artesanais. Nosso blend bovino é moído diariamente, usamos apenas ingredientes frescos e selecionados, sem conservantes."
  },
  {
    question: "Quais são as formas de pagamento?",
    answer: "Aceitamos cartões de crédito e débito das principais bandeiras, Pix e dinheiro (solicite troco no momento do pedido)."
  },
  {
    question: "Vocês têm opções vegetarianas?",
    answer: "Trabalhamos para oferecer a melhor experiência, verifique nosso cardápio no WhatsApp para as opções especiais do mês."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-32 bg-dark">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-16">
          <h2 className="text-sm uppercase tracking-widest text-brand mb-3 font-semibold">Dúvidas Frequentes</h2>
          <h3 className="text-4xl md:text-5xl font-display font-bold text-white">Perguntas Rápidas</h3>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            
            return (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`border rounded-2xl overflow-hidden transition-colors ${
                  isOpen ? 'bg-white/[0.03] border-white/10' : 'bg-transparent border-white/5 hover:border-white/10'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  className="w-full text-left p-6 flex items-center justify-between focus:outline-none"
                >
                  <span className="font-bold text-white pr-8">{faq.question}</span>
                  <ChevronDown className={`w-5 h-5 text-brand transition-transform duration-300 shrink-0 ${
                    isOpen ? 'rotate-180' : ''
                  }`} />
                </button>
                
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-6 pb-6 text-white/60 text-sm leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
