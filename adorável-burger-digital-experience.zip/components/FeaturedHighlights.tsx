'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Plus, Star } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { MENU_ITEMS, MenuItem } from '@/lib/menuData';
import { useCart } from './CartProvider';
import { useToast } from './ToastProvider';
import ProductModal from './ProductModal';

export default function FeaturedHighlights() {
  const featuredItems = MENU_ITEMS.filter((item) => item.isFeatured).slice(0, 4);
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const { addItem } = useCart();
  const { showToast } = useToast();

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleQuickAdd = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      quantity: 1,
    });

    showToast({
      title: item.name,
      description: 'Adicionado ao carrinho!',
      image: item.image,
      type: 'cart',
    });
  };

  return (
    <section id="destaques" className="py-32 bg-dark-surface relative overflow-hidden z-10 border-y border-white/5">
      {/* Background Lighting */}
      <div className="absolute top-1/2 right-0 w-[40vw] h-[40vw] bg-white/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full text-xs font-bold text-amber-400 uppercase tracking-widest mb-4">
              <Sparkles className="w-3.5 h-3.5" /> Destaques da Casa
            </div>
            <h2 className="text-4xl md:text-6xl font-display font-bold text-white tracking-tight">
              Criações <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-white/40">Inesquecíveis</span>
            </h2>
          </div>

          <Link
            href="/cardapio"
            className="inline-flex items-center gap-3 bg-white hover:bg-amber-300 text-dark px-8 py-4 rounded-full font-bold text-base transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.15)] group self-start md:self-end"
          >
            <span>Ver Cardápio Completo</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Featured Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onClick={() => setSelectedProduct(item)}
              className="group relative bg-dark border border-white/10 rounded-3xl overflow-hidden hover:border-white/30 transition-all duration-500 flex flex-col cursor-pointer shadow-xl hover:-translate-y-2"
            >
              <div className="relative h-60 bg-black overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark via-transparent to-transparent opacity-80" />

                {item.badge && (
                  <span className="absolute top-4 left-4 bg-white text-dark text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider shadow-lg">
                    {item.badge}
                  </span>
                )}
                {item.rating && (
                  <span className="absolute top-4 right-4 bg-black/60 backdrop-blur-md text-white text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    {item.rating}
                  </span>
                )}
              </div>

              <div className="p-6 flex flex-col flex-grow justify-between space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-white mb-1 group-hover:text-amber-200 transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-white/60 text-xs leading-relaxed line-clamp-2">
                    {item.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                  <span className="text-xl font-bold text-amber-400">{formatPrice(item.price)}</span>
                  <button
                    onClick={(e) => handleQuickAdd(e, item)}
                    className="w-9 h-9 rounded-full bg-white/10 hover:bg-white text-white hover:text-dark flex items-center justify-center transition-all duration-300"
                    title="Adicionar ao Pedido"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Banner Teaser */}
        <div className="mt-16 bg-gradient-to-r from-white/10 via-white/5 to-transparent border border-white/10 p-8 sm:p-12 rounded-3xl flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-2 text-center lg:text-left">
            <h3 className="text-2xl sm:text-3xl font-display font-bold text-white">
              Quer ver mais opções do nosso menu?
            </h3>
            <p className="text-white/70 text-sm sm:text-base max-w-xl">
              Temos smashs prensados na chapa, acompanhamentos trufados, sobremesas exclusivas e bebidas geladas.
            </p>
          </div>

          <Link
            href="/cardapio"
            className="shrink-0 bg-white hover:bg-amber-300 text-dark font-bold px-8 py-4 rounded-full text-base transition-all shadow-lg flex items-center gap-2"
          >
            Acessar Cardápio Interativo
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>

      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </section>
  );
}
