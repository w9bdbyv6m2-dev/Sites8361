'use client';

import { ArrowRight, Instagram, Facebook, MapPin, ShoppingBag } from 'lucide-react';
import Link from 'next/link';
import MagneticButton from './MagneticButton';
import { useCart } from './CartProvider';

export default function Footer() {
  const { setIsCartOpen } = useCart();

  return (
    <footer className="bg-dark pt-32 pb-10 border-t border-white/5">
      <div className="container mx-auto px-6 max-w-7xl">
        
        {/* CTA Section */}
        <div className="bg-white rounded-3xl p-12 md:p-16 flex flex-col md:flex-row items-center justify-between gap-8 mb-32 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-black/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3" />
          
          <div className="relative z-10 max-w-xl text-center md:text-left">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-dark mb-4">Pronto para o Melhor Burger?</h2>
            <p className="text-dark/80 text-lg font-medium">Faça seu pedido agora e receba em casa com toda a qualidade Adorável.</p>
          </div>
          
          <MagneticButton 
            onClick={() => setIsCartOpen(true)}
            className="relative z-10 shrink-0 inline-flex items-center gap-3 bg-dark text-white px-8 py-4 rounded-full text-lg font-bold transition-all hover:bg-dark/90 shadow-2xl"
          >
            Fazer Pedido
            <ShoppingBag className="w-5 h-5" />
          </MagneticButton>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-1">
            <Link href="/" className="inline-block mb-6">
              <span className="font-display text-2xl font-bold tracking-tight text-white">
                Adorável<span className="text-brand">.</span>
              </span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed mb-6">
              O verdadeiro hambúrguer artesanal de Vicente Pires. Ingredientes frescos, blend selecionado e paixão em cada detalhe.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:text-white hover:bg-brand transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:text-white hover:bg-brand transition-all">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Navegação</h4>
            <ul className="space-y-4">
              <li><Link href="#cardapio" className="text-white/60 hover:text-brand transition-colors text-sm">Cardápio</Link></li>
              <li><Link href="#mais-pedidos" className="text-white/60 hover:text-brand transition-colors text-sm">Mais Pedidos</Link></li>
              <li><Link href="#sobre" className="text-white/60 hover:text-brand transition-colors text-sm">Nossa História</Link></li>
              <li><Link href="#localizacao" className="text-white/60 hover:text-brand transition-colors text-sm">Localização</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Horários</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li>Quarta a Segunda</li>
              <li className="text-white">17:40 às 23:40</li>
              <li className="pt-2">Terça-feira</li>
              <li className="text-white">Fechado</li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Contato</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-brand shrink-0" />
                <span>Rua 08, Chácara 206, 01 - LJ 01<br/>Vicente Pires, Brasília - DF</span>
              </li>
              <li>
                <a href="mailto:contato@adoravelburger.com.br" className="hover:text-brand transition-colors">contato@adoravelburger.com.br</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-white/40">
          <p>&copy; {new Date().getFullYear()} Adorável Burger. Todos os direitos reservados.</p>
          <p>Design premium para restaurantes.</p>
        </div>
      </div>
    </footer>
  );
}
