'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import { X, ZoomIn, Sparkles } from 'lucide-react';
import Tilt3DCard from './Tilt3DCard';

const IMAGES = [
  {
    src: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=80",
    title: "Adorável Clássico",
    caption: "Pão brioche selado com blend Angus 180g"
  },
  {
    src: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=1200&q=80",
    title: "Smash Chipotle & Gouda",
    caption: "Crosta de Maillard com aroma de pimenta chipotle"
  },
  {
    src: "https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=1200&q=80",
    title: "Bacon Supreme",
    caption: "Fatias espessas de bacon artesanal crocante"
  },
  {
    src: "https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=1200&q=80",
    title: "Batata Rústica Trufada",
    caption: "Crocante por fora, macia por dentro com azeite de trufas"
  },
  {
    src: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1200&q=80",
    title: "Cozinha Artesanal",
    caption: "Preparado com carinho e paixão na nossa grelha"
  },
  {
    src: "https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&w=1200&q=80",
    title: "Milkshake Belga",
    caption: "Sorvete cremoso batido com chocolate autoral"
  }
];

export default function Gallery() {
  const [activeImage, setActiveImage] = useState<typeof IMAGES[0] | null>(null);

  return (
    <section className="py-28 bg-dark overflow-hidden relative">
      <div className="container mx-auto px-6 max-w-7xl mb-16 text-center">
        <motion.span
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-3"
        >
          Galeria de Fotos
        </motion.span>
        <motion.h3
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-display font-bold text-white"
        >
          Experiência Visual Incomparável
        </motion.h3>
      </div>

      <div className="w-full flex gap-6 px-6 overflow-x-auto pb-8 snap-x snap-mandatory scrollbar-none">
        {IMAGES.map((img, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: idx * 0.1 }}
            className="shrink-0 w-[80vw] sm:w-[45vw] lg:w-[28vw] h-[450px] rounded-3xl overflow-hidden snap-center cursor-pointer group relative"
            onClick={() => setActiveImage(img)}
          >
            <Tilt3DCard maxTilt={8} scaleOnHover={1.03} className="w-full h-full">
              <div className="relative w-full h-full bg-dark-surface border border-white/10 rounded-3xl overflow-hidden">
                <Image
                  src={img.src}
                  alt={img.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700 transform-gpu"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/90 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <ZoomIn className="w-4 h-4" />
                </div>

                <div className="absolute bottom-6 left-6 right-6">
                  <span className="text-amber-400 text-xs font-bold uppercase tracking-wider block mb-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Adorável Burger
                  </span>
                  <h4 className="text-white text-xl font-bold">{img.title}</h4>
                  <p className="text-white/60 text-xs mt-1 line-clamp-1">{img.caption}</p>
                </div>
              </div>
            </Tilt3DCard>
          </motion.div>
        ))}
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {activeImage && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveImage(null)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="relative max-w-4xl w-full bg-dark border border-white/15 rounded-3xl overflow-hidden shadow-2xl z-10"
            >
              <button
                onClick={() => setActiveImage(null)}
                className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/70 border border-white/20 text-white flex items-center justify-center hover:bg-white hover:text-dark transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative w-full h-[60vh] bg-black">
                <Image
                  src={activeImage.src}
                  alt={activeImage.title}
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="p-6 bg-dark-surface border-t border-white/10">
                <h3 className="text-2xl font-bold text-white mb-1">{activeImage.title}</h3>
                <p className="text-white/70 text-sm">{activeImage.caption}</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
