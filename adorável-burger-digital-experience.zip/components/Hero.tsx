'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Star, MapPin, Sparkles, Flame, Check } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import MagneticButton from './MagneticButton';
import Tilt3DCard from './Tilt3DCard';
import { useCart } from './CartProvider';
import { useToast } from './ToastProvider';

const HERO_FEATURED = [
  {
    id: 'hero-1',
    name: 'Bacon Supreme',
    tagline: 'O N° 1 em Vendas em Vicente Pires',
    price: 38.90,
    rating: '5.0',
    prepTime: '20-25 min',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=1600&q=80',
    description: 'Blend Angus 180g, muito bacon artesanal crocante, queijo cheddar inglês derretido e cebola caramelizada autoral.',
  },
  {
    id: 'hero-2',
    name: 'Smash Chipotle & Trufas',
    tagline: 'Crosta Crocante & Aroma Incomparável',
    price: 36.90,
    rating: '4.9',
    prepTime: '15-20 min',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=1600&q=80',
    description: 'Dois smashes Angus 90g prensados na chapa trincando, queijo gouda cremoso, azeite de trufas e maionese chipotle.',
  },
  {
    id: 'hero-3',
    name: 'Adorável Clássico',
    tagline: 'A Essência da Nossa Cozinha',
    price: 32.90,
    rating: '4.9',
    prepTime: '15-20 min',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1600&q=80',
    description: 'Pão brioche fofinho selado na manteiga de garrafa, blend 180g suculento, queijo prato duplo, alface romana e tomate fresco.',
  }
];

export default function Hero() {
  const [selectedBurger, setSelectedBurger] = useState(HERO_FEATURED[0]);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();
  const { showToast } = useToast();

  const formatPrice = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const handleQuickAdd = () => {
    addItem({
      id: selectedBurger.id,
      name: selectedBurger.name,
      price: selectedBurger.price,
      image: selectedBurger.image,
      quantity: 1,
    });

    setAdded(true);
    setTimeout(() => setAdded(false), 1500);

    showToast({
      title: selectedBurger.name,
      description: 'Adicionado ao seu pedido!',
      image: selectedBurger.image,
      type: 'cart',
    });
  };

  return (
    <section className="relative min-h-[100svh] flex flex-col items-center justify-center pt-28 pb-16 overflow-hidden bg-dark">
      {/* Ambient Radial Lighting Motion background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="w-[85vw] h-[85vw] bg-amber-500/10 rounded-full blur-[150px] max-w-[1000px] max-h-[1000px]"
        />
      </div>

      <div className="container mx-auto px-6 max-w-7xl relative z-20 flex flex-col items-center text-center">
        
        {/* Top Live Status Indicator & Rating Pill */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-3 bg-white/5 border border-white/10 px-5 py-2.5 rounded-full text-xs sm:text-sm text-white/90 backdrop-blur-md mb-8 shadow-2xl"
        >
          <span className="flex items-center gap-1.5 font-bold text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Cozinha Aberta
          </span>
          <span className="w-1 h-1 rounded-full bg-white/30" />
          <span className="flex items-center gap-1 font-semibold text-amber-400">
            <Star className="w-4 h-4 fill-amber-400" /> 4.9 no iFood
          </span>
          <span className="w-1 h-1 rounded-full bg-white/30 hidden sm:inline" />
          <span className="hidden sm:flex items-center gap-1 text-white/70">
            <MapPin className="w-4 h-4 text-amber-400" /> Vicente Pires • DF
          </span>
        </motion.div>

        {/* Main Headline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="z-30 max-w-4xl"
        >
          <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-display font-bold text-white leading-[0.92] tracking-tight mb-6">
            O Hambúrguer.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-white/40">
              Reinventado.
            </span>
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-white/70 mb-8 max-w-2xl mx-auto font-light leading-relaxed px-4">
            Perfeição artesanal com blend de carnes nobres Angus e molhos autorais na cozinha de Vicente Pires.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <MagneticButton
              href="/cardapio"
              className="group relative inline-flex items-center justify-center gap-3 bg-white text-dark px-10 py-5 rounded-full text-lg font-bold transition-all hover:bg-amber-300 shadow-[0_0_40px_rgba(255,255,255,0.2)] active:scale-95"
            >
              <Sparkles className="w-5 h-5 text-dark" />
              <span>Explorar Cardápio Exclusivo</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </MagneticButton>

            <Link
              href="#combos"
              className="px-8 py-5 text-white/80 hover:text-white font-semibold text-base transition-colors flex items-center gap-2 group"
            >
              <span>Ver Ofertas Especiais</span>
              <span className="group-hover:translate-y-1 transition-transform">↓</span>
            </Link>
          </div>
        </motion.div>

        {/* Interactive 3D Showcase Frame & Burger Switcher */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="w-full max-w-4xl"
        >
          {/* Quick Interactive Selector Tabs */}
          <div className="flex items-center justify-center gap-2 mb-4 overflow-x-auto pb-2 scrollbar-none">
            {HERO_FEATURED.map((burger) => {
              const isSelected = selectedBurger.id === burger.id;
              return (
                <button
                  key={burger.id}
                  onClick={() => setSelectedBurger(burger)}
                  className={`px-4 py-2 rounded-full text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-amber-400 text-dark font-extrabold shadow-lg scale-105'
                      : 'bg-white/5 border border-white/10 text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Flame className={`w-3.5 h-3.5 ${isSelected ? 'fill-dark' : 'text-amber-400'}`} />
                  {burger.name}
                </button>
              );
            })}
          </div>

          {/* 3D Perspective Tilt Card */}
          <Tilt3DCard maxTilt={10} scaleOnHover={1.02} className="w-full">
            <div className="relative w-full aspect-[16/9] max-h-[480px] rounded-3xl overflow-hidden shadow-[0_25px_90px_rgba(0,0,0,0.9)] border border-white/15 group bg-dark-surface">
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedBurger.id}
                  initial={{ opacity: 0, scale: 1.08 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0"
                >
                  <Image
                    src={selectedBurger.image}
                    alt={selectedBurger.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-1000 transform-gpu"
                    priority
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/30 to-transparent opacity-90" />
                </motion.div>
              </AnimatePresence>

              {/* Top Floating Badge */}
              <div className="absolute top-6 left-6 z-20 flex items-center gap-2">
                <span className="bg-black/80 backdrop-blur-md border border-white/20 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-full shadow-xl flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> {selectedBurger.tagline}
                </span>
              </div>

              {/* Bottom Interactive Info Bar */}
              <div className="absolute bottom-6 left-6 right-6 z-20 bg-black/75 backdrop-blur-xl border border-white/20 p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left shadow-2xl">
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl sm:text-2xl font-bold text-white">{selectedBurger.name}</h3>
                    <span className="text-lg font-black text-amber-400">{formatPrice(selectedBurger.price)}</span>
                  </div>
                  <p className="text-white/70 text-xs sm:text-sm mt-1 max-w-xl line-clamp-1 sm:line-clamp-2">
                    {selectedBurger.description}
                  </p>
                </div>

                <button
                  onClick={handleQuickAdd}
                  className={`shrink-0 px-6 py-3.5 rounded-full text-xs font-extrabold uppercase tracking-wider transition-all shadow-lg flex items-center gap-2 active:scale-95 ${
                    added
                      ? 'bg-emerald-500 text-white'
                      : 'bg-white text-dark hover:bg-amber-300'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Adicionado!</span>
                    </>
                  ) : (
                    <>
                      <Flame className="w-4 h-4 fill-dark" />
                      <span>Pedir Este Burger</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </Tilt3DCard>
        </motion.div>
      </div>
    </section>
  );
}
