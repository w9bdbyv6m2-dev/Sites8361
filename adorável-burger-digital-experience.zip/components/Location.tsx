'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Phone, ExternalLink, Copy, Check } from 'lucide-react';
import { useToast } from './ToastProvider';

export default function Location() {
  const [copied, setCopied] = useState(false);
  const { showToast } = useToast();

  const handleCopyAddress = () => {
    navigator.clipboard.writeText('Rua 08, Chácara 206, 01 - LJ 01, Vicente Pires, Brasília - DF');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);

    showToast({
      title: 'Endereço Copiado!',
      description: 'Cole no seu GPS ou aplicativo de transporte.',
      type: 'info',
    });
  };

  return (
    <section id="localizacao" className="py-28 bg-dark relative overflow-hidden">
      <div className="container mx-auto px-6 max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-dark-surface border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
        >
          
          <div className="p-8 sm:p-12 lg:p-16 flex flex-col justify-center space-y-8">
            <div>
              <span className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-3">
                Onde nos Encontrar
              </span>
              <h3 className="text-3xl sm:text-5xl font-display font-bold text-white mb-2">
                Venha Conhecer Nossa Casa
              </h3>
              <p className="text-white/60 text-sm sm:text-base font-light">
                Ambiente aconchegante para retirada presencial ou entrega rápida na sua porta.
              </p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center shrink-0 text-amber-400">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white mb-1">Endereço Principal</h4>
                  <p className="text-white/70 text-sm leading-relaxed">
                    Rua 08, Chácara 206, 01 - LJ 01<br />
                    Vicente Pires, Brasília - DF<br />
                    CEP: 72006-865
                  </p>
                  
                  <div className="flex flex-wrap items-center gap-3 mt-3">
                    <a 
                      href="https://goo.gl/maps/adoravelburger" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-bold hover:text-amber-300 transition-colors"
                    >
                      Abrir no Google Maps <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    <button
                      onClick={handleCopyAddress}
                      className="inline-flex items-center gap-1.5 text-white/60 hover:text-white text-xs font-semibold bg-white/5 border border-white/10 px-3 py-1 rounded-full transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copiado!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copiar Endereço</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center shrink-0 text-amber-400">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white mb-1">Horários de Atendimento</h4>
                  <p className="text-white/70 text-sm leading-relaxed">
                    Terça a Domingo: <strong className="text-white">17:40 às 23:40</strong><br />
                    Segunda-feira: <span className="text-amber-400 font-semibold">Fechado para descanso da equipe</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center shrink-0 text-amber-400">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white mb-1">Pedidos Direct & WhatsApp</h4>
                  <p className="text-white/70 text-sm leading-relaxed">
                    Atendimento imediato pelo nosso WhatsApp:<br />
                    <a
                      href="https://wa.me/5561999999999"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-400 font-bold hover:underline"
                    >
                      (61) 99999-9999
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative h-[400px] lg:h-auto min-h-[450px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15357.653634125712!2d-48.02611755!3d-15.82362545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x935a33118cf9bebb%3A0x8dd33deceeaeb7b6!2sR.%208%20Ch%C3%A1cara%20206%20Lote%201%20A%20-%20St.%20Hab.%20Vicente%20Pires%2C%20Bras%C3%ADlia%20-%20DF%2C%2072006-865!5e0!3m2!1spt-BR!2sbr!4v1700000000000!5m2!1spt-BR!2sbr"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0 transition-all duration-700"
            ></iframe>
            <div className="absolute inset-0 ring-1 ring-inset ring-white/10 pointer-events-none" />
          </div>
          
        </motion.div>
      </div>
    </section>
  );
}
