'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { Plus } from 'lucide-react';
import { useCart } from './CartProvider';

const CATEGORIES = ['Todos', 'Hambúrgueres', 'Smash Burgers', 'Combos', 'Porções', 'Bebidas'];

const MENU_ITEMS = [
  {
    id: 1,
    name: 'Adorável Clássico',
    description: 'Blend bovino 160g, queijo prato derretido, alface americana, tomate confit, cebola roxa e maionese da casa no pão brioche.',
    price: 38.00,
    category: 'Hambúrgueres',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    name: 'Bacon Supreme',
    description: 'Blend bovino 160g, duplo cheddar, tiras de bacon crocante, cebola caramelizada e molho barbecue artesanal.',
    price: 44.00,
    category: 'Hambúrgueres',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    name: 'Smash Duplo',
    description: '2x ultramashes bovinos 80g, queijo prato, picles, cebola picada, ketchup e mostarda no pão macio.',
    price: 32.00,
    category: 'Smash Burgers',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 4,
    name: 'Truffle Burger',
    description: 'Blend bovino 160g, creme de queijo brie, cogumelos salteados e azeite trufado no pão australiano.',
    price: 48.00,
    category: 'Hambúrgueres',
    image: 'https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 5,
    name: 'Combo Adorável',
    description: 'Adorável Clássico + Batata Frita Individual + Refrigerante Lata.',
    price: 55.00,
    category: 'Combos',
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 6,
    name: 'Batata Rústica Trufada',
    description: 'Porção de batatas rústicas finalizadas com azeite de trufas brancas e parmesão ralado.',
    price: 28.00,
    category: 'Porções',
    image: 'https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&w=800&q=80'
  }
];

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const { addItem } = useCart();

  const filteredItems = MENU_ITEMS.filter(item => 
    activeCategory === 'Todos' ? true : item.category === activeCategory
  );

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <section id="cardapio" className="py-32 bg-dark-surface relative z-10">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <h2 className="text-sm uppercase tracking-widest text-brand mb-3 font-semibold">Nosso Menu</h2>
            <h3 className="text-4xl md:text-5xl font-display font-bold text-white">Descubra Nossos <br/>Sabores Únicos</h3>
          </div>
          
          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                  activeCategory === category 
                  ? 'bg-white text-dark shadow-[0_0_20px_rgba(255,255,255,0.1)]' 
                  : 'bg-transparent text-white/60 hover:text-white hover:bg-white/5 border border-white/10'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={item.id}
                className="group flex flex-col bg-dark border border-white/5 rounded-2xl overflow-hidden hover:border-white/10 transition-colors"
              >
                <div className="relative h-64 overflow-hidden bg-black">
                  <Image 
                    src={item.image}
                    alt={item.name}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-105 group-hover:opacity-80"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-60" />
                </div>
                
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex justify-between items-start mb-3 gap-4">
                    <h4 className="text-xl font-bold text-white">{item.name}</h4>
                    <span className="text-brand font-medium whitespace-nowrap">{formatPrice(item.price)}</span>
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed mb-6 flex-grow">
                    {item.description}
                  </p>
                  
                  <button 
                    onClick={() => addItem({
                      id: item.id,
                      name: item.name,
                      price: item.price,
                      image: item.image,
                      quantity: 1
                    })}
                    className="inline-flex items-center justify-center gap-2 w-full py-3 bg-white hover:bg-white/90 text-dark rounded-xl transition-colors text-sm font-semibold"
                  >
                    <Plus className="w-4 h-4" />
                    Adicionar ao Pedido
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
