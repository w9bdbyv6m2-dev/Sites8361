'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ShoppingBag } from 'lucide-react';
import Link from 'next/link';
import MagneticButton from './MagneticButton';
import { useCart } from './CartProvider';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const { items, setIsCartOpen } = useCart();
  
  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const scrolled = window.scrollY > 40;
          setIsScrolled((prev) => (prev !== scrolled ? scrolled : prev));
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Cardápio Exclusivo', href: '/cardapio' },
    { name: 'Combos & Ofertas', href: '/#combos' },
    { name: 'Mais Pedidos', href: '/#mais-pedidos' },
    { name: 'Nossa História', href: '/#sobre' },
    { name: 'Localização', href: '/#localizacao' },
  ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-dark/90 backdrop-blur-xl border-b border-white/10 py-4 shadow-2xl' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 max-w-7xl flex items-center justify-between">
        <Link href="/" className="relative z-10 flex items-center gap-2 group">
          <span className="font-display text-2xl md:text-3xl font-bold tracking-tight text-white group-hover:text-amber-400 transition-colors">
            Adorável<span className="text-amber-400 group-hover:text-white transition-colors">.</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-7">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="text-sm font-semibold text-white/70 hover:text-white transition-colors relative group py-1"
            >
              {link.name}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-amber-400 transition-all duration-300 group-hover:w-full" />
            </Link>
          ))}

          <MagneticButton
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2.5 bg-white text-dark px-6 py-2.5 rounded-full text-sm font-bold hover:bg-amber-300 transition-all shadow-[0_0_25px_rgba(255,255,255,0.15)] active:scale-95"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2.5 -right-2.5 bg-amber-400 text-dark text-[10px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center animate-pulse">
                  {cartItemCount}
                </span>
              )}
            </div>
            <span>Meu Pedido</span>
          </MagneticButton>
        </nav>

        {/* Mobile Buttons */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-2.5 rounded-full bg-white/10 text-white border border-white/10 active:scale-95 transition-transform"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-amber-400 text-dark text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </button>

          <button
            className="p-2 text-white/80 hover:text-white focus:outline-none"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-dark-surface/95 backdrop-blur-2xl border-b border-white/10 p-6 md:hidden flex flex-col gap-5 shadow-2xl"
          >
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="text-lg font-semibold text-white/80 hover:text-amber-400 transition-colors py-1"
              >
                {link.name}
              </Link>
            ))}

            <button
              onClick={() => {
                setIsOpen(false);
                setIsCartOpen(true);
              }}
              className="flex justify-center items-center gap-2 bg-white text-dark px-6 py-3.5 rounded-full text-base font-bold mt-2 shadow-lg active:scale-95 transition-transform"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Ver Pedido ({cartItemCount})</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
