'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, ShoppingBag, Clock, Flame, Star, Sparkles } from 'lucide-react';
import Image from 'next/image';
import { MenuItem } from '@/lib/menuData';
import { useCart } from './CartProvider';
import { useToast } from './ToastProvider';

interface ProductModalProps {
  product: MenuItem | null;
  onClose: () => void;
}

function ProductModalContent({ product, onClose }: { product: MenuItem; onClose: () => void }) {
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const { addItem } = useCart();
  const { showToast } = useToast();

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity,
      notes,
    });

    showToast({
      title: `${quantity}x ${product.name}`,
      description: 'Adicionado ao seu pedido!',
      image: product.image,
      type: 'cart',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-md z-[-1]"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20, filter: 'blur(10px)' }}
        animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
        exit={{ opacity: 0, scale: 0.9, y: 20, filter: 'blur(10px)' }}
        transition={{ type: 'spring', damping: 25, stiffness: 250 }}
        className="relative w-full max-w-2xl bg-dark border border-white/15 rounded-3xl overflow-hidden shadow-[0_25px_70px_rgba(0,0,0,0.9)] my-8"
      >
        {/* Top Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center justify-center hover:bg-white hover:text-dark transition-all duration-300"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Image Header */}
        <div className="relative w-full h-72 sm:h-80 bg-black">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/40 to-transparent" />

          {/* Badges */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2 z-10">
            {product.badge && (
              <span className="bg-white text-dark text-xs font-extrabold px-3 py-1.5 rounded-full uppercase tracking-wider shadow-lg flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {product.badge}
              </span>
            )}
            {product.rating && (
              <span className="bg-black/70 backdrop-blur-md border border-white/20 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                {product.rating}
              </span>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <div>
            <div className="flex justify-between items-start gap-4 mb-2">
              <h3 className="text-2xl sm:text-3xl font-display font-bold text-white">{product.name}</h3>
              <span className="text-2xl font-bold text-amber-400">{formatPrice(product.price)}</span>
            </div>
            <p className="text-white/70 text-sm sm:text-base leading-relaxed">{product.description}</p>
          </div>

          {/* Meta Chips */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-white/60 pt-2 border-t border-white/10">
            {product.prepTime && (
              <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Preparo: {product.prepTime}</span>
              </div>
            )}
            {product.calories && (
              <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
                <Flame className="w-4 h-4 text-amber-400" />
                <span>{product.calories}</span>
              </div>
            )}
          </div>

          {/* Ingredients List */}
          {product.ingredients && product.ingredients.length > 0 && (
            <div>
              <h4 className="text-xs uppercase tracking-wider text-white/50 font-bold mb-2.5">Ingredientes Selecionados</h4>
              <div className="flex flex-wrap gap-2">
                {product.ingredients.map((ing, idx) => (
                  <span key={idx} className="bg-white/5 border border-white/10 text-white/80 text-xs px-3 py-1 rounded-lg">
                    {ing}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Custom Observations Note */}
          <div>
            <label className="block text-xs uppercase tracking-wider text-white/50 font-bold mb-2">
              Observações do Pedido (Opcional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Tirar cebola, carne ao ponto, molho à parte..."
              className="w-full bg-white/5 border border-white/15 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-white transition-colors"
            />
          </div>

          {/* Quantity and Actions Bar */}
          <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 border-t border-white/10">
            {/* Quantity Controls */}
            <div className="flex items-center bg-white/5 border border-white/15 rounded-full p-1.5 w-full sm:w-auto justify-between sm:justify-start">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-12 text-center text-white font-bold text-base">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add Button */}
            <button
              onClick={handleAddToCart}
              className="flex-1 w-full py-4 bg-white text-dark rounded-full font-bold text-base hover:bg-amber-300 transition-all flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(255,255,255,0.2)] active:scale-98"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Adicionar • {formatPrice(product.price * quantity)}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function ProductModal({ product, onClose }: ProductModalProps) {
  return (
    <AnimatePresence>
      {product && (
        <ProductModalContent key={product.id} product={product} onClose={onClose} />
      )}
    </AnimatePresence>
  );
}
