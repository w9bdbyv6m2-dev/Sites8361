'use client';

import { motion } from 'framer-motion';
import { Star, Quote, CheckCircle2 } from 'lucide-react';
import Tilt3DCard from './Tilt3DCard';

const REVIEWS = [
  {
    name: "Carlos Eduardo M.",
    role: "Cliente Frequente em Vicente Pires",
    text: "O melhor hambúrguer de Vicente Pires, sem dúvidas. A carne de blend Angus é extremamente suculenta e o pão brioche vem perfeitamente selado. Atendimento e pontualidade nota 10!",
    rating: 5,
    date: "Há 2 dias no iFood"
  },
  {
    name: "Ana Paula Silva",
    role: "Moradora de Águas Claras",
    text: "Pedi o Bacon Supreme e foi uma das melhores experiências gastronômicas do meu ano. O bacon é crocante de verdade e o molho autoral é viciante. Já virou rotina no fim de semana.",
    rating: 5,
    date: "Há 4 dias"
  },
  {
    name: "Rafael Torres",
    role: "Cliente em Taguatinga",
    text: "Embalagem fantástica que mantém a batata rústica trufada super crocante e o hambúrguer quentinho. A maionese verde autoral é maravilhosa. Recomendo de olhos fechados!",
    rating: 5,
    date: "Há 1 semana"
  }
];

export default function Reviews() {
  return (
    <section className="py-28 bg-dark-surface border-y border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-block mb-3"
          >
            Avaliações 100% Reais
          </motion.span>

          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-display font-bold text-white mb-4"
          >
            O Que Dizem Nossos Clientes
          </motion.h3>

          <p className="text-white/60 text-sm sm:text-base">
            Mais de <strong className="text-amber-400">1.200 pedidos entregues</strong> com nota média <strong className="text-white">4.9 ★</strong> no iFood.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {REVIEWS.map((review, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
            >
              <Tilt3DCard maxTilt={8} scaleOnHover={1.03} className="h-full">
                <div className="bg-dark border border-white/10 p-8 rounded-3xl flex flex-col h-full relative group hover:border-amber-400/40 transition-colors shadow-xl">
                  <Quote className="absolute top-6 right-6 w-10 h-10 text-white/5 group-hover:text-amber-400/10 transition-colors pointer-events-none" />

                  <div className="flex items-center gap-1 mb-6">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                    <span className="ml-2 text-xs text-white/40 font-semibold">{review.date}</span>
                  </div>

                  <p className="text-white/80 leading-relaxed font-light text-sm sm:text-base italic flex-grow mb-8">
                    &quot;{review.text}&quot;
                  </p>

                  <div className="flex items-center gap-4 pt-6 border-t border-white/10 mt-auto">
                    <div className="w-11 h-11 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-dark font-extrabold flex items-center justify-center text-sm shadow-md">
                      {review.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-white text-sm">{review.name}</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      </div>
                      <span className="text-xs text-white/50 block">{review.role}</span>
                    </div>
                  </div>
                </div>
              </Tilt3DCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
