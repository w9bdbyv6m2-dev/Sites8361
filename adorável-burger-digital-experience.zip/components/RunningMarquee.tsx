'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Flame, Star, Sparkles } from 'lucide-react';

const ITEMS = [
  'HAMBÚRGUER ARTESANAL',
  'BLEND ANGUS 100% CERTIFICADO',
  'PÃO BRIOCHE SELADO NA MANTEIGA',
  'MOLHOS AUTORAIS DA CASA',
  'VICENTE PIRES - DF',
  'ENTREGA RÁPIDA & QUENTINHA',
  'AVALIAÇÃO 4.9★ NO IFOOD',
];

export default function RunningMarquee() {
  return (
    <div className="w-full bg-amber-400 text-dark py-3.5 overflow-hidden border-y border-amber-300 font-extrabold uppercase tracking-wider text-xs sm:text-sm select-none shadow-lg">
      <div className="flex whitespace-nowrap">
        <motion.div
          animate={{ x: ['0%', '-50%'] }}
          transition={{
            repeat: Infinity,
            duration: 22,
            ease: 'linear',
          }}
          className="flex gap-8 items-center shrink-0 pr-8"
        >
          {[...ITEMS, ...ITEMS, ...ITEMS, ...ITEMS].map((item, idx) => (
            <div key={idx} className="flex items-center gap-8">
              <span>{item}</span>
              <Sparkles className="w-4 h-4 fill-dark shrink-0" />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
