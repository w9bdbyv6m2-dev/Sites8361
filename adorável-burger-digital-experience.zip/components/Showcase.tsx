'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';

export default function Showcase() {
  return (
    <section className="py-28 bg-dark relative overflow-hidden border-b border-white/5">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Text Column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full text-xs font-bold text-amber-400 uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" /> Alta Gastronomia Artesanal
            </div>

            <h2 className="text-4xl sm:text-6xl font-display font-bold text-white leading-[1.1] tracking-tight">
              Profundidade de Sabor.<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-white/40">
                Texturas Incomparáveis.
              </span>
            </h2>

            <p className="text-white/70 text-lg font-light leading-relaxed max-w-xl">
              Cada hambúrguer é uma obra de arte gastronômica. Selecionamos carnes nobres com certificação Angus, grelhadas no fogo forte para criar a crosta perfeita e manter o interior incrivelmente suculento.
            </p>

            <div className="pt-4">
              <Link
                href="/cardapio"
                className="inline-flex items-center gap-3 bg-white hover:bg-amber-300 text-dark px-8 py-4 rounded-full font-bold text-base transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.15)] group"
              >
                <span>Ver Nossas Criações na Aba Cardápio</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>

          {/* Right Image Frame */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative h-[480px] sm:h-[580px] rounded-3xl overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.8)] border border-white/10 group"
          >
            <Image
              src="https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=1600&q=80"
              alt="Adorável Burger Obra de Arte"
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-1000 transform-gpu"
              priority
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/20 to-transparent opacity-80" />

            <div className="absolute bottom-8 left-8 right-8 bg-black/60 backdrop-blur-md border border-white/15 p-6 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-amber-400 font-bold text-xs uppercase tracking-wider mb-1">Qualidade sem atalhos</p>
                <p className="text-white font-bold text-lg">Pão Selado & Molho Autoral</p>
              </div>
              <span className="text-white/40 text-xs font-semibold hidden sm:inline">DF • Vicente Pires</span>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
