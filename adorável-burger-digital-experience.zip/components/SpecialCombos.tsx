'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, Check, Flame } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import Tilt3DCard from './Tilt3DCard';

const COMBOS = [
  {
    id: 'combo-duplo',
    title: 'Combo Adorável Duplo',
    subtitle: 'O favorito dos casais & amigos',
    price: 'R$ 68,90',
    originalPrice: 'R$ 82,00',
    savings: 'Economize R$ 13,10',
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80',
    badge: 'Mais Vendido',
    items: [
      '2x Burgers à sua escolha (Angus ou Smash)',
      '1x Batata Rústica Grande com Maionese Autoral',
      '2x Bebidas Geladas (Refrigerante ou Suco)'
    ]
  },
  {
    id: 'combo-smash-trufado',
    title: 'Combo Smash & Trufada',
    subtitle: 'Experiência gastronômica completa',
    price: 'R$ 52,90',
    originalPrice: 'R$ 61,00',
    savings: 'Economize R$ 8,10',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80',
    badge: 'Edição Especial',
    items: [
      '1x Smash Chipotle ou Truffle Burger',
      '1x Batata Crinkle com Azeite de Trufas',
      '1x Bebida Refrescante 350ml'
    ]
  },
  {
    id: 'combo-galera',
    title: 'Combo Adorável Galera',
    subtitle: 'Para compartilhar em família',
    price: 'R$ 119,90',
    originalPrice: 'R$ 142,00',
    savings: 'Economize R$ 22,10',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    badge: 'Super Oferta',
    items: [
      '4x Burgers Artesanais',
      '2x Porções Grandes de Batata com Bacon & Cheddar',
      '1x Guaraná 1.5L ou Coca-Cola 1.5L'
    ]
  }
];

export default function SpecialCombos() {
  return (
    <section id="combos" className="py-28 bg-dark relative overflow-hidden border-b border-white/5">
      {/* Ambient Lighting Glow */}
      <div className="absolute top-1/3 left-0 w-[50vw] h-[50vw] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-xs font-extrabold uppercase tracking-widest text-amber-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full inline-flex items-center gap-2 mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" /> Combos Especiais da Semana
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-6xl font-display font-bold text-white tracking-tight"
          >
            Economize com Nossos <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-white/40">Combos Autorais</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-white/70 text-base sm:text-lg mt-4 font-light"
          >
            Sabor incomparável acompanhado de batatas crocantes e bebidas bem geladas. Peça pelo nosso cardápio na aba exclusiva.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {COMBOS.map((combo, index) => (
            <motion.div
              key={combo.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
            >
              <Tilt3DCard maxTilt={8} scaleOnHover={1.03} className="h-full">
                <div className="bg-dark-surface border border-white/10 rounded-3xl overflow-hidden flex flex-col justify-between hover:border-amber-400/40 transition-colors duration-300 group shadow-2xl h-full">
                  <div>
                    <div className="relative h-56 bg-black overflow-hidden">
                      <Image
                        src={combo.image}
                        alt={combo.title}
                        fill
                        className="object-cover group-hover:scale-108 transition-transform duration-700 transform-gpu"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-dark-surface via-transparent to-transparent opacity-90" />

                      <span className="absolute top-4 left-4 bg-amber-400 text-dark text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-lg flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 fill-dark" /> {combo.badge}
                      </span>

                      <span className="absolute bottom-3 right-4 bg-emerald-500/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full border border-emerald-400/30">
                        {combo.savings}
                      </span>
                    </div>

                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="text-2xl font-bold text-white group-hover:text-amber-300 transition-colors">
                          {combo.title}
                        </h3>
                        <p className="text-white/60 text-xs mt-1">{combo.subtitle}</p>
                      </div>

                      <div className="flex items-baseline gap-3 py-2 border-y border-white/5">
                        <span className="text-2xl font-black text-amber-400">{combo.price}</span>
                        <span className="text-sm text-white/40 line-through font-semibold">{combo.originalPrice}</span>
                      </div>

                      <ul className="space-y-2.5 pt-1">
                        {combo.items.map((item, i) => (
                          <li key={i} className="flex items-start gap-2.5 text-xs text-white/80 leading-relaxed">
                            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="p-6 pt-0">
                    <Link
                      href="/cardapio"
                      className="w-full py-3.5 bg-white text-dark rounded-full font-bold text-sm hover:bg-amber-300 transition-all flex items-center justify-center gap-2 shadow-lg active:scale-98"
                    >
                      <span>Pedir no Cardápio</span>
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </Tilt3DCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
