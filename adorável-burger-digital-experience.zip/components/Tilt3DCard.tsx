'use client';

import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

interface Tilt3DCardProps {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number;
  scaleOnHover?: number;
}

export default function Tilt3DCard({
  children,
  className = '',
  maxTilt = 12,
  scaleOnHover = 1.03,
}: Tilt3DCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0.5);
  const y = useMotionValue(0.5);

  const rotateXSpring = useSpring(useTransform(y, [0, 1], [maxTilt, -maxTilt]), {
    stiffness: 250,
    damping: 20,
  });

  const rotateYSpring = useSpring(useTransform(x, [0, 1], [-maxTilt, maxTilt]), {
    stiffness: 250,
    damping: 20,
  });

  const scaleSpring = useSpring(1, { stiffness: 250, damping: 20 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const xPct = mouseX / rect.width;
    const yPct = mouseY / rect.height;

    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseEnter = () => {
    scaleSpring.set(scaleOnHover);
  };

  const handleMouseLeave = () => {
    x.set(0.5);
    y.set(0.5);
    scaleSpring.set(1);
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX: rotateXSpring,
        rotateY: rotateYSpring,
        scale: scaleSpring,
        transformStyle: 'preserve-3d',
      }}
      className={`relative perspective-1000 ${className}`}
    >
      {children}
    </motion.div>
  );
}
