export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: 'Hambúrgueres Artesanais' | 'Smash Burgers' | 'Combos' | 'Acompanhamentos' | 'Bebidas' | 'Sobremesas';
  image: string;
  badge?: 'Mais Vendido' | 'Novo' | 'Chef' | 'Promoção';
  tags?: string[];
  ingredients?: string[];
  prepTime?: string;
  calories?: string;
  rating?: number;
  isFeatured?: boolean;
}

export const MENU_CATEGORIES = [
  'Todos',
  'Hambúrgueres Artesanais',
  'Smash Burgers',
  'Combos',
  'Acompanhamentos',
  'Bebidas',
  'Sobremesas',
] as const;

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 1,
    name: 'Adorável Clássico',
    description: 'Blend bovino Angus 160g, queijo prato derretido, alface americana crocante, tomate confit, cebola roxa marinada e maionese artesanal no pão brioche amanteigado.',
    price: 38.00,
    category: 'Hambúrgueres Artesanais',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1000&q=80',
    badge: 'Mais Vendido',
    tags: ['Clássico', 'Bovino'],
    ingredients: ['Pão Brioche', 'Blend Angus 160g', 'Queijo Prato', 'Alface Americana', 'Tomate Confit', 'Cebola Roxa', 'Maionese Especial'],
    prepTime: '15-20 min',
    calories: '680 kcal',
    rating: 4.9,
    isFeatured: true
  },
  {
    id: 2,
    name: 'Bacon Supreme',
    description: 'Blend bovino 160g, duplo cheddar inglês derretido, tiras generosas de bacon defumado crocante, cebola caramelizada e molho barbecue artesanal defumado.',
    price: 44.00,
    category: 'Hambúrgueres Artesanais',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=1000&q=80',
    badge: 'Chef',
    tags: ['Bacon', 'Cheddar'],
    ingredients: ['Pão Brioche', 'Blend Angus 160g', 'Duplo Cheddar', 'Bacon Defumado', 'Cebola Caramelizada', 'Barbecue Artesanal'],
    prepTime: '15-20 min',
    calories: '820 kcal',
    rating: 5.0,
    isFeatured: true
  },
  {
    id: 3,
    name: 'Smash Duplo Jalapeño',
    description: '2x ultra smashes bovinos 80g com crosta caramelizada, queijo prato, picles artesanais, rodelas frescas de jalapeño e molho chipotle levemente picante.',
    price: 34.00,
    category: 'Smash Burgers',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=1000&q=80',
    badge: 'Novo',
    tags: ['Apimentado', 'Smash'],
    ingredients: ['Pão Macio', '2x Smash 80g', 'Queijo Prato', 'Picles', 'Jalapeño', 'Molho Chipotle'],
    prepTime: '10-15 min',
    calories: '620 kcal',
    rating: 4.8,
    isFeatured: true
  },
  {
    id: 4,
    name: 'Truffle Brie Burger',
    description: 'Blend bovino 160g, generosa fatia de queijo brie empanado, cogumelos paris salteados na manteiga e maionese trufada no pão australiano selado.',
    price: 49.00,
    category: 'Hambúrgueres Artesanais',
    image: 'https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&w=1000&q=80',
    badge: 'Chef',
    tags: ['Trufado', 'Premium'],
    ingredients: ['Pão Australiano', 'Blend Angus 160g', 'Queijo Brie', 'Cogumelos Paris', 'Maionese Trufada'],
    prepTime: '20 min',
    calories: '790 kcal',
    rating: 4.9,
    isFeatured: true
  },
  {
    id: 5,
    name: 'Smash Triple Cheese',
    description: '3x discos de smash 70g prensados com cebola ralada, triplo cheddar cremoso, maionese da casa e ketchup no pão fofinho de batata.',
    price: 36.00,
    category: 'Smash Burgers',
    image: 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=1000&q=80',
    badge: 'Mais Vendido',
    tags: ['Smash', 'Cheese'],
    ingredients: ['Pão de Batata', '3x Smash 70g', 'Triplo Cheddar', 'Cebola na Chapa', 'Maionese Especial'],
    prepTime: '10 min',
    calories: '750 kcal',
    rating: 4.9
  },
  {
    id: 6,
    name: 'Combo Casal Adorável',
    description: '2x Adorável Clássico ou Bacon Supreme + 1 Porção Grande de Batata Rústica Trufada + 2x Bebidas à sua escolha.',
    price: 89.00,
    category: 'Combos',
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1000&q=80',
    badge: 'Promoção',
    tags: ['Combo', 'Especial'],
    ingredients: ['2 Burgers Escolhidos', '1 Porção Grande Batata', '2 Bebidas'],
    prepTime: '20 min',
    calories: '1500 kcal',
    rating: 5.0,
    isFeatured: true
  },
  {
    id: 7,
    name: 'Veggie Portobello',
    description: 'Cogumelo Portobello grelhado recheado com queijo gorganzola e murcho de espinafre, tomate seco e molho aioli no pão brioche.',
    price: 39.00,
    category: 'Hambúrgueres Artesanais',
    image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?auto=format&fit=crop&w=1000&q=80',
    tags: ['Vegetariano'],
    ingredients: ['Pão Brioche', 'Cogumelo Portobello', 'Gorgonzola', 'Espinafre', 'Tomate Seco', 'Aioli'],
    prepTime: '15 min',
    calories: '510 kcal',
    rating: 4.7
  },
  {
    id: 8,
    name: 'Batata Rústica Trufada com Parmesão',
    description: 'Porção crocante de batatas rústicas cortadas à mão, finalizadas com azeite de trufas brancas importado e chuva de queijo parmesão ralado na hora.',
    price: 28.00,
    category: 'Acompanhamentos',
    image: 'https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&w=1000&q=80',
    badge: 'Mais Vendido',
    tags: ['Trufado', 'Petisco'],
    ingredients: ['Batatas Rústicas', 'Azeite de Trufas', 'Parmesão Ralado', 'Ervas Finas'],
    prepTime: '10 min',
    calories: '420 kcal',
    rating: 4.9
  },
  {
    id: 9,
    name: 'Onion Rings Crocantes',
    description: 'Anéis de cebola empanados em farinha panko temperada, servidos com dip de molho barbecue defumado.',
    price: 24.00,
    category: 'Acompanhamentos',
    image: 'https://images.unsplash.com/photo-1639024471283-03518883512d?auto=format&fit=crop&w=1000&q=80',
    tags: ['Petisco'],
    ingredients: ['Cebola Doce', 'Empanamento Panko', 'Molho Barbecue'],
    prepTime: '10 min',
    calories: '380 kcal',
    rating: 4.6
  },
  {
    id: 10,
    name: 'Milkshake de Nutella com Ninho',
    description: 'Sorvete artesanal de baunilha batido com creme de Nutella pura, mesclado com calda de Leite Ninho e chantilly no topo.',
    price: 26.00,
    category: 'Sobremesas',
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=1000&q=80',
    badge: 'Novo',
    tags: ['Doce', 'Shake'],
    ingredients: ['Sorvete de Baunilha', 'Nutella Original', 'Leite Ninho', 'Chantilly'],
    prepTime: '5 min',
    calories: '580 kcal',
    rating: 5.0
  },
  {
    id: 11,
    name: 'Brownie com Sorvete e Calda Quente',
    description: 'Brownie fofinho e úmido de chocolate meio amargo 70%, servido quente com bola de sorvete fava de baunilha e ganache de chocolate.',
    price: 22.00,
    category: 'Sobremesas',
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=1000&q=80',
    tags: ['Doce', 'Chocolate'],
    ingredients: ['Brownie Cacau 70%', 'Sorvete Baunilha', 'Ganache Quente'],
    prepTime: '5 min',
    calories: '490 kcal',
    rating: 4.8
  },
  {
    id: 12,
    name: 'Soda Artesanal de Frutas Vermelhas',
    description: 'Infusão gelada de amora, framboesa e morango com água gaseificada, rodelas de limão siciliano e hortelã fresca.',
    price: 14.00,
    category: 'Bebidas',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=1000&q=80',
    tags: ['Gelado', 'Refrescante'],
    ingredients: ['Xarope Artesanal de Amora', 'Água com Gás', 'Limão Siciliano', 'Hortelã'],
    prepTime: '3 min',
    calories: '110 kcal',
    rating: 4.8
  },
  {
    id: 13,
    name: 'Coca-Cola Zero / Normal Lata 350ml',
    description: 'Lata trincando de gelada com fatia de limão opcional.',
    price: 8.00,
    category: 'Bebidas',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=1000&q=80',
    tags: ['Bebida'],
    prepTime: '2 min',
    calories: '140 kcal',
    rating: 4.9
  }
];
